window.onload = function(){
	document.querySelector('.boton').addEventListener('click', function(){
		document.querySelector('.aside').classList.toggle('invisi');
	});
}