<?php
	function hora()
	{
		//date_default_timezone_set("America/Caracas");
		$hora=date("H:i:s");
		return ($hora);
	}
	function fecha()
	{
		//date_default_timezone_set("America/Caracas");
		$fecha=date("y/m/d");
		return($fecha);
	}


?>